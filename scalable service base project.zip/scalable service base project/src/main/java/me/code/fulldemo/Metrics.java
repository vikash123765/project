package me.code.fulldemo;

public class Metrics {

    public final double cpuLoad;
    public final long usedMemory;
    public final long maxMemory;
    public final int threadCount;

    public Metrics(double processCpuLoad, long usedHeapSize, long maxHeapSize, int activeThreadCount) {
        this.cpuLoad = processCpuLoad;
        this.usedMemory = usedHeapSize;
        this.maxMemory = maxHeapSize;
        this.threadCount = activeThreadCount;
    }
}
