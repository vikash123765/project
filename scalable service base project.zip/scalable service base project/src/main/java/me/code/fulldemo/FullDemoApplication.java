package me.code.fulldemo;

import com.sun.management.OperatingSystemMXBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.ThreadMXBean;

@SpringBootApplication
public class FullDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(FullDemoApplication.class, args);
    }

    public static Metrics getMetrics() {
        OperatingSystemMXBean osBean = ManagementFactory.getPlatformMXBean(
                OperatingSystemMXBean.class);

        // What % CPU load this current JVM is taking.
        double processCpuLoad = osBean.getProcessCpuLoad() * 100;

        MemoryMXBean memBean = ManagementFactory.getMemoryMXBean();
        long usedHeapSize = memBean.getHeapMemoryUsage().getUsed();
        long maxHeapSize = memBean.getHeapMemoryUsage().getMax();


        ThreadMXBean threadBean = ManagementFactory.getThreadMXBean();
        int activeThreadCount = threadBean.getThreadCount();

        return new Metrics(processCpuLoad, usedHeapSize, maxHeapSize, activeThreadCount);
    }
}
