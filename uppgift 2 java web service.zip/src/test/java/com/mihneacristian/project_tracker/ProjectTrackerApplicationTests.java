package com.mihneacristian.project_tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectTrackerApplicationTests {

    @Test
    void contextLoads() {
    }

}
